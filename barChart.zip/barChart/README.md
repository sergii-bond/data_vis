A simple SVG bar chart.
Part of the tutorial series [Let’s Make a Bar Chart](http://bost.ocks.org/mike/bar/).